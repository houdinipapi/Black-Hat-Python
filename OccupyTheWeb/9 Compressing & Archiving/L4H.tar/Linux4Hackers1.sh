#!/bin/bash

# Simple script

echo "Name: "
read name
echo "Favorite Language: "
read language

echo "Hello $name, I like $language too"
